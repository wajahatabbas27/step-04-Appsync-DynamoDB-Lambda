declare const getTodos: () => Promise<any>;
export default getTodos;
