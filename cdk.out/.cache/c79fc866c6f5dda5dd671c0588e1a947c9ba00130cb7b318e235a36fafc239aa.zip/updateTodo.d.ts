declare const updateTodo: (todo: any) => Promise<any>;
export default updateTodo;
