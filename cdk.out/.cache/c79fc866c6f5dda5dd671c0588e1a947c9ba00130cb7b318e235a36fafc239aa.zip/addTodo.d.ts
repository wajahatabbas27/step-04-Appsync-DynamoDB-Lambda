import Todo from './Todo';
declare const addTodo: (todo: Todo) => Promise<Todo | null>;
export default addTodo;
