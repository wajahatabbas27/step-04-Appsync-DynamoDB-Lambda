declare const deleteTodo: (todoId: String) => Promise<String | null>;
export default deleteTodo;
